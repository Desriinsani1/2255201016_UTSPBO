<?php
//Desri Insani
//2255201016
echo "code ". "academy ";
 
 echo "\nMy name is : Desri Insani";
 echo "\nClass : B";
 echo "\nNIM: 22552010116"; 
 echo"\nThis. is a string that starts on a new line!";