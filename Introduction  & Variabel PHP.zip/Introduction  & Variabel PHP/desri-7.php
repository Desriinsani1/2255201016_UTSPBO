<?php
// Desri insani
//2255202016
  $movie = "attack on titan";
  $old_favorite = " demon slayer";
// Add your code here:



  echo "I'm a fickle person, my favorite movie used to be $movie.";
  
// Add a statement here:
  
  
  echo "\nBut now my favorite is $old_favorite.";
  
// Add a statement below: