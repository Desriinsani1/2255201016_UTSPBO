<?php
//Desri Insani
//2255201016

/* Imagine a lot of code here */  
  $order= "15 chicken wings";
  $very_bad_unclear_name =& $order;

// Write your code here:

  // Don't change the line below
  echo "\nYour order is: $very_bad_unclear_name.";