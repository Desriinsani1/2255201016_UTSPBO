<?php
//Desri Insani
//2255201016
// Write your code below:
  echo "1. Teach PHP";
 echo "\n2. Eat breakfast";
 echo "\n3. Learn to have \"fun\""; 
 echo"\nThis. is a string that starts on a new line!";