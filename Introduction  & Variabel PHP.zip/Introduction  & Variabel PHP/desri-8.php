<?php
// Desri Insani
// 2255201016
  $example = "Desri";
$part2 = ", Insani";
$example .= $part2;
$part3 = "!";
$example .= $part3;
echo $example; // Prints: Hello, World!
// Write your code below: