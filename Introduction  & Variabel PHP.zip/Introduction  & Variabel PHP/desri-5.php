<?php
// Desri Insani
//2255201016
// Write your code below:
 $first_example = "Hello My name's Desri Insani!";
$second_example = "My Nim 2255201016.";
  $thing = "variables";
echo "I love concatenating " . $thing;
  $food = "burgers";
echo "\nI love " . $food;