<?php
// Desri insani
//2255202016
// Fill in the blanks in the code below:
  $adjective= " Silly";
  $noun = "helicopter";
  $adjective = "powerful";
  $verb = "scream";

  echo "The world's most beloved $noun  was very $adjective and loved to $verb every single day.";